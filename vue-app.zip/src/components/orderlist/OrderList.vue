<template>
  <div class="orderlist-container">
    <div class="header">
      <span>订单</span>
    </div>
    <div class="content">
      <span class="list-icon"><i class="icon iconfont icon-dingdan"></i></span>
      <p class="not-found">没有找到相关信息</p>
      <p class="more-info">您可以试试其他条件，或者到处逛逛</p>

    </div>

  </div>
</template>
<script>

  export default {
    mouted(){

    },
    data() {
      return {


      };
    },
    methods:{

    }
  };
</script>
